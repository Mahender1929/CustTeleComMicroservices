package com.cedge;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CedgeTelecomUiClientApplicationTests {

	@Test
	void contextLoads() {
	}

}
