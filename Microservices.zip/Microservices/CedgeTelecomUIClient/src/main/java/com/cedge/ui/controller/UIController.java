package com.cedge.ui.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.ParameterizedTypeReference;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.client.RestTemplate;

import com.cedge.ui.model.CallDetailsDTO;
import com.cedge.ui.model.CustomerDTO;
import com.cedge.ui.model.Friend;
import com.cedge.ui.model.Login;
import com.cedge.ui.model.PlanDTO;

@Controller
public class UIController {
	
	@Autowired
	RestTemplate restTemplate;
	
	@GetMapping("/index")
	public String getIndexPage(){
		return "index";
	}
	@GetMapping("/loginPage")
	public String getLoginPage(){
		return "login";
	}
	
	
	//**************Customer LOGIN Validation**************************
	
	private static String LOGIN_URL="http://localhost:5547/CustomerDetailAPI/login";
	@PostMapping("/loginCustomer")
	public String loginCustomer(@RequestParam Long phoneNo,@RequestParam String password, Model model,HttpServletRequest req)
	{ HttpSession session = req.getSession(true);
	
	session.setAttribute("PhoneNoo", phoneNo);
		Login login = new Login();
		login.setPhoneNo(phoneNo);
		login.setPassword(password);
		
		boolean flag = restTemplate.postForObject(LOGIN_URL, login, boolean.class);
		if(flag==true){
			return "home";
		}else
		{
			model.addAttribute("message","Bad credentials......!");
			return "login";
		}
	}
	
	//************** ALL_PLANS**************************
	
	private static String ALL_PLANS_URL="http://localhost:5545/PlanDetailAPI/allPlans";
	@GetMapping("/allPlans")
	public String allPlans(Model model)
	{
		List<PlanDTO> listPlanDTO = restTemplate.getForObject(ALL_PLANS_URL, List.class);
		model.addAttribute("allPlans",listPlanDTO);
		return "allPlans";
	}
	
	//**************Customer CALL_DETAILS**************************
	
	private static String CALL_DETAILS="http://localhost:5544/CallDetailAPI/{phoneNumber}";
	@GetMapping("/callDetails")
	public String callDetails(Model model,HttpSession session)
	{
		Long phoneNo = (Long)session.getAttribute("PhoneNoo");
		List<CallDetailsDTO> callDetailsDTO = restTemplate.getForObject(CALL_DETAILS, List.class,phoneNo);
		model.addAttribute("callDetails",callDetailsDTO);
		return "callDetails";
	}
	
	//**************Customer VIEW_PROFILE**************************
	
	private static String VIEW_PROFILE_URL="http://localhost:5547/CustomerDetailAPI/profile/{phoneNo}";
	@GetMapping("viewProfile")
	public String viewProfile(Model model,HttpSession session)
	{
		Long phoneNo = (Long)session.getAttribute("PhoneNoo");
		ParameterizedTypeReference<CustomerDTO> typeRef = new ParameterizedTypeReference<CustomerDTO>(){};
		ResponseEntity<CustomerDTO> responseEntity = restTemplate.exchange(VIEW_PROFILE_URL, HttpMethod.GET, null, typeRef, phoneNo);
		CustomerDTO profileCustomerDTO = responseEntity.getBody();
		//List  profileCustomerDTO = restTemplate.getForObject(VIEW_PROFILE_URL,List.class,phoneNo);
		model.addAttribute("viewProfile",profileCustomerDTO);
		return "viewProfile";
	}
	
	//**************Customer ADD_FRIEND**************************
	@GetMapping("addFriend")
	public String getaddFriend(){
		return "addFriend";
	}
	
	private static String ADD_FRIEND_URL="http://localhost:5546/FriendDetailAPI/addFriend";
	@PostMapping("/addFriendDetails")
	public String addFriendDetails(@RequestParam Integer palnId,@RequestParam Long friendNo, Model model,HttpSession session){
		Long phoneNoo = (Long)session.getAttribute("PhoneNoo");
		Friend friend = new Friend();
		friend.setFriendNo(friendNo);
		friend.setId(palnId);
		friend.setPhoneNo(phoneNoo);
		
		String flag = restTemplate.postForObject(ADD_FRIEND_URL, friend, String.class);
			model.addAttribute("success",flag);
			return "addFriend";
		
	}
	
	//**************Customer DELETE_FRIEND**************************
		@GetMapping("deleteFriendsContact")
		public String getdeleteFriend(){
			return "deleteFriend";
		}
		
		private static String DELETE_FRIEND_URL="http://localhost:5546/FriendDetailAPI/deleteFriend";
		@PostMapping("/deleteFriendDetails")
		public String deleteFriendDetails(@RequestParam Long friendNo, Model model,HttpSession session){
			Long phoneNoo = (Long)session.getAttribute("PhoneNoo");
			Friend friend = new Friend();
			friend.setFriendNo(friendNo);
			friend.setPhoneNo(phoneNoo);
			
			String flag = restTemplate.postForObject(DELETE_FRIEND_URL, friend, String.class);
				model.addAttribute("deletesuccess",flag);
				return "deleteFriend";
		}
		
		//**************Customer VIEW_FRIEND**************************
		
		private static String VIEW_FRIEND_URL="http://localhost:5546/FriendDetailAPI/friends/{phoneNo}";
		@GetMapping("viewFriendsContact")
		public String viewFriends(Model model,HttpSession session)
		{
			Long phoneNo = (Long)session.getAttribute("PhoneNoo");
			ParameterizedTypeReference<List> typeRef = new ParameterizedTypeReference<List>(){};
			ResponseEntity<List> responseEntity = restTemplate.exchange(VIEW_FRIEND_URL, HttpMethod.GET, null, typeRef, phoneNo);
			List viewFriendsDTO = responseEntity.getBody();
			model.addAttribute("viewFriends",viewFriendsDTO);
			return "viewFriendsContact";
		}
		
		
}
