package com.cedge.service.impl;

import java.util.Optional;


import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cedge.entity.Customer;
import com.cedge.model.dto.CustomerDTO;
import com.cedge.model.dto.Login;
import com.cedge.repository.CustomerRepository;
import com.cedge.service.ICustomerService;

@Service
public class CustomerServiceImpl implements ICustomerService {

	@Autowired
	CustomerRepository repository;
	
	
	@Override
	public boolean registerCustomer(Customer customer) {
		boolean flag = repository.existsById(customer.getPhoneNo());
		if(flag==true)
		{
			return false;
		}
		else
		{
			repository.save(customer);
			return true;
		}
	}

	@Override
	public boolean loginCheck(Login login) {
		int flag = repository.customerCount(login.getPhoneNo(), login.getPassword());
		if(flag == 0)
		{
			return false;
		}else{
		return true;
		}
	}

	@Override
	public CustomerDTO getProfile(Long phoneNo) {
		Optional<Customer> opt = repository.findById(phoneNo);
		Customer customer = opt.get();
		CustomerDTO customerdto = new CustomerDTO();
		BeanUtils.copyProperties(customer, customerdto);
		return customerdto;
	}
	

}
