package com.cedge.service;

import com.cedge.entity.Customer;
import com.cedge.model.dto.CustomerDTO;
import com.cedge.model.dto.Login;

public interface ICustomerService {
	boolean registerCustomer(Customer customer);
	boolean loginCheck(Login login);
	CustomerDTO getProfile(Long phoneNo);
}
