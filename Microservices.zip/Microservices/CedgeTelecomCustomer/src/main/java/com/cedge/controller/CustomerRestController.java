package com.cedge.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.cedge.entity.Customer;
import com.cedge.model.dto.CustomerDTO;
import com.cedge.model.dto.Login;
import com.cedge.model.dto.PlanDTO;
import com.cedge.service.ICustomerService;

@RestController
public class CustomerRestController {
	
	@Autowired
	ICustomerService service;
	
	@Autowired
	RestTemplate restTemplate;
	
	@PostMapping(value="/register",consumes="application/json")
	public String register(@RequestBody Customer customer)
	{
		boolean flag = service.registerCustomer(customer);
		if(flag==true)
		{
			return "Customer registered";
		}
		else
		{
			return "Customer Already Exists with the Id";
		}
	}
	private static String PLAN_URL = "http://localhost:5545/PlanDetailAPI/{planId}";
	private static String FRIEND_URL = "http://localhost:5546/FriendDetailAPI/friends/{phoneNo}";

	@PostMapping("/login")
	public boolean verifyLogin(@RequestBody Login login)
	{
		return service.loginCheck(login);
	}
	
	@GetMapping("/profile/{phoneNo}")
	public CustomerDTO viewProfile(@PathVariable Long phoneNo)
	{
		CustomerDTO customerDTO = service.getProfile(phoneNo);

		//call planDetails Microservice
		PlanDTO planDTO = restTemplate.getForObject(PLAN_URL, PlanDTO.class,customerDTO.getPlanId());
		customerDTO.setPlanDTO(planDTO);
		
		//call friend Microservice
		
		List friendsContactNumber = restTemplate.getForObject(FRIEND_URL, List.class, customerDTO.getPhoneNo());
		customerDTO.setFriendsContactNumber(friendsContactNumber);
		return customerDTO;
	}
}
