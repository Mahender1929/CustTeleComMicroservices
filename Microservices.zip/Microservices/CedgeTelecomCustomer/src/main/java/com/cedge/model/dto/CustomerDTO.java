package com.cedge.model.dto;

import java.util.List;

public class CustomerDTO {

	private Long phoneNo;
	private String password;
	private String planId;
	private PlanDTO planDTO;
	private List friendsContactNumber;
	public Long getPhoneNo() {
		return phoneNo;
	}
	public void setPhoneNo(Long phoneNo) {
		this.phoneNo = phoneNo;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getPlanId() {
		return planId;
	}
	public void setPlanId(String planId) {
		this.planId = planId;
	}
	public PlanDTO getPlanDTO() {
		return planDTO;
	}
	public void setPlanDTO(PlanDTO planDTO) {
		this.planDTO = planDTO;
	}
	public List getFriendsContactNumber() {
		return friendsContactNumber;
	}
	public void setFriendsContactNumber(List friendsContactNumber) {
		this.friendsContactNumber = friendsContactNumber;
	}
	
	
}
