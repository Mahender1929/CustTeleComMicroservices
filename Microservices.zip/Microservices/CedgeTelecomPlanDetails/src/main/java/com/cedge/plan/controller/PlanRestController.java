package com.cedge.plan.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.cedge.plan.dto.PlanDTO;
import com.cedge.plan.service.IPlanService;

@RestController
public class PlanRestController {
	@Autowired
	IPlanService service;
	
	@GetMapping(value="/allPlans", produces="application/json")
	public List<PlanDTO> getAllPlans()
	{
		List<PlanDTO> allPlans = service.getAllPlan();
		return allPlans;
	}
	
	@GetMapping(value="/{planId}", produces="application/json")
	public PlanDTO getPalnById(@PathVariable String planId)
	{
		PlanDTO planById = service.getPlanById(planId);
		return planById;
	}

}
