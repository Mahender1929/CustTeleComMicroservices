package com.cedge;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CedgeTelecomApplicationP {

	public static void main(String[] args) {
		SpringApplication.run(CedgeTelecomApplicationP.class, args);
	}

}
