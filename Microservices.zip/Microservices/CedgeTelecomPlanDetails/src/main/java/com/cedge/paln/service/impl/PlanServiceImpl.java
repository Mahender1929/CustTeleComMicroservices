package com.cedge.paln.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cedge.plan.dto.PlanDTO;
import com.cedge.plan.entity.Plan;
import com.cedge.plan.repository.PlanRepository;
import com.cedge.plan.service.IPlanService;

@Service
public class PlanServiceImpl implements IPlanService{

	@Autowired
	PlanRepository repo;
	
	
	@Override
	public List<PlanDTO> getAllPlan() {
		List<Plan> findAllPlan = repo.findAll();
		List<PlanDTO> findPalnDTO = new ArrayList<PlanDTO>();
		
		for(Plan plan: findAllPlan)
		{
			PlanDTO planDTO = new PlanDTO();
			BeanUtils.copyProperties(plan, planDTO);
			findPalnDTO.add(planDTO);
		}
		return findPalnDTO;
	}

	@Override
	public PlanDTO getPlanById(String planId) {
		java.util.Optional<Plan> findById = repo.findById(planId);
		Plan plan = findById.get();
		PlanDTO planDTO = new PlanDTO();
		BeanUtils.copyProperties(plan, planDTO);
		return planDTO;
	}

}
