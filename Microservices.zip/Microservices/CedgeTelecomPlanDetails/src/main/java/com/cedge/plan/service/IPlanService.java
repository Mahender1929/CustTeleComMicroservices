package com.cedge.plan.service;

import java.util.List;

import com.cedge.plan.dto.PlanDTO;

public interface IPlanService {

	List<PlanDTO> getAllPlan();
	PlanDTO getPlanById(String planId);
	
}
