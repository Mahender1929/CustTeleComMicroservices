package com.cedge;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CedgeTelecomApplicationC {

	public static void main(String[] args) {
		SpringApplication.run(CedgeTelecomApplicationC.class, args);
	}

}
