package com.cedge.service;

import java.util.List;

import com.cedge.dto.CallDetailsDTO;

public interface ICallDetailsService {
	List<CallDetailsDTO> getCallDetailsByPhoneNumber(Long calledBy);

}
