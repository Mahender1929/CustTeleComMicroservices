package com.cedge.serviceimpl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cedge.dto.CallDetailsDTO;
import com.cedge.entity.CallDetails;
import com.cedge.repository.CallDetailsRepository;
import com.cedge.service.ICallDetailsService;

@Service
public class CallDetailsServiceImpl implements ICallDetailsService{

	@Autowired
	CallDetailsRepository repository;
	
	@Override
	public List<CallDetailsDTO> getCallDetailsByPhoneNumber(Long calledBy) {
		
		List<CallDetails> CallDetailsList = repository.findByCalledBy(calledBy);
		List<CallDetailsDTO> CallDetailsDTOList = new ArrayList<CallDetailsDTO>();
		for(CallDetails CallDetails : CallDetailsList){
			CallDetailsDTO dto = new CallDetailsDTO();
			BeanUtils.copyProperties(CallDetails, dto);
			CallDetailsDTOList.add(dto);
		}
		return CallDetailsDTOList;
	}

}
