package com.cedge.friend.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.cedge.friend.entity.Friend;

@Repository
public interface FriendRepository extends JpaRepository<Friend, Integer> {

	@Query(value="select count(*) from friend where phone_no=?",nativeQuery=true)
	Integer VerifyFriendNo(Long phoneNo);
	
	@Query(value="select id from friend where friend_no=?",nativeQuery=true)
	Integer VerifyFriendNoDelete(Long friendNo);

	List<Friend> findByPhoneNo(Long phoneNo);

	@Query(value="delete from friend where friend_no=?",nativeQuery=true)
	public void deleteFriendNo(Long friendNo);

}
