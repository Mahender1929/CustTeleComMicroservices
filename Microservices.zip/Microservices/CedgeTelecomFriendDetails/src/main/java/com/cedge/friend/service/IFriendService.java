package com.cedge.friend.service;

import java.util.List;

import com.cedge.friend.entity.Friend;

public interface IFriendService {

	public String addFriendService(Friend friend);
	public String deleteFriendService(Friend friend);
	public List<Long> getListFriendNoByPhoneNo(Long phoneNo);
}
