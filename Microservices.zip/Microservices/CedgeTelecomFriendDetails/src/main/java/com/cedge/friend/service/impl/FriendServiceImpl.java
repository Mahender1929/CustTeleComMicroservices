package com.cedge.friend.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cedge.friend.entity.Friend;
import com.cedge.friend.repository.FriendRepository;
import com.cedge.friend.service.IFriendService;

@Service
public class FriendServiceImpl implements IFriendService{
	@Autowired
	FriendRepository repository;

	@Override
	public String addFriendService(Friend friend) {
		Integer count =repository.VerifyFriendNo(friend.getPhoneNo());
		if(!(count==0))
		{
			repository.save(friend);
			return "friend is added";
		}
		else
		{
			return "friend contact is already exists";
		}
	}

	@Override
	public List<Long> getListFriendNoByPhoneNo(Long phoneNo) {
		
		List<Friend> friendList = repository.findByPhoneNo(phoneNo);
		List<Long> friendContactList = new ArrayList<>();
		
		for(Friend friend : friendList)
		{
			Long friendsContact = friend.getFriendNo();
			friendContactList.add(friendsContact);
		}
		return friendContactList;
	}
	@Override
	public String deleteFriendService(Friend friend) {
		Integer count =repository.VerifyFriendNoDelete(friend.getFriendNo());
		friend.setId(count);
		if(!(count==0))
		{
			repository.delete(friend);
			
			//repository.deleteFriendNo(friend.getFriendNo());
			return "friend is deleted";
		}
		else
		{
			return "friend contact is not exists";
		}
	}
	
	

}
