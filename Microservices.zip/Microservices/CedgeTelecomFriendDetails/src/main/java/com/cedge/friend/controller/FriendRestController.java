package com.cedge.friend.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cedge.friend.entity.Friend;
import com.cedge.friend.service.impl.FriendServiceImpl;

@RestController
public class FriendRestController {

	@Autowired
	FriendServiceImpl service;
	
	@PostMapping(value="/addFriend")
	public String addFriend(@RequestBody Friend friend)
	{
		return service.addFriendService(friend);
	}
	
	
	
	@PostMapping(value="/deleteFriend")
	public String deleteFriend(@RequestBody Friend friend)
	{
		return service.deleteFriendService(friend);
	}
	
	
	@GetMapping(value="/friends/{phoneNo}" , produces="application/json")
	public List<Long> getListFriendNoByPhoneNo(@PathVariable Long phoneNo)
	{
		List<Long> list = service.getListFriendNoByPhoneNo(phoneNo);
		return list;
	}
}
